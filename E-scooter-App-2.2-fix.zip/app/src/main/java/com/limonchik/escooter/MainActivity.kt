package com.limonchik.escooter

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var pending: (() -> Unit)? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) pending?.invoke()
        pending = null
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun ensurePerms(then: () -> Unit) {
        val need = perms().filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) then() else { pending = then; permLauncher.launch(need.toTypedArray()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EScooterTheme(vm.theme) {
                LaunchedEffect(vm.keepOn) {
                    if (vm.keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
                Surface(color = MaterialTheme.colorScheme.background) {
                    App(vm) { ensurePerms { vm.openScan() } }
                }
            }
        }
    }

    private fun hasPerms() = perms().all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    // автоподключение при каждом возврате в приложение (если разрешения уже даны и вы не отключались вручную)
    override fun onStart() {
        super.onStart()
        if (vm.onboarded && vm.prefs.lastAddr != null && hasPerms()) vm.autoConnect()
    }
}

@Composable
fun App(vm: MainViewModel, requestScan: () -> Unit) {
    LaunchedEffect(vm.onboarded) { if (vm.onboarded) vm.maybeShowTg() }
    if (!vm.onboarded) Onboarding(vm) else MainScreen(vm, requestScan)
    if (vm.scanOpen) ScanDialog(vm)
    if (vm.showTg) TgDialog(vm)
}
