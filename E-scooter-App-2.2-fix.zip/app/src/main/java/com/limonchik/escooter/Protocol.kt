package com.limonchik.escooter

data class Telemetry(
    val speed: Float = 0f, val battery: Int = 0, val trip: Float = 0f, val total: Float = 0f,
    val temp: Float = 0f, val error: Int = 0, val uptime: Int = 0
)

class Frame(val addr: Int, val cmd: Int, val reg: Int, val data: ByteArray)

/** Ninebot / Xiaomi M365 UART-over-BLE protocol: 55 AA | L | addr | cmd | reg | payload | checksum(LE) */
object Protocol {
    private fun frame(cmd: Int, reg: Int, payload: ByteArray): ByteArray {
        val core = byteArrayOf((payload.size + 2).toByte(), 0x20, cmd.toByte(), reg.toByte()) + payload
        var sum = 0
        for (b in core) sum += b.toInt() and 0xFF
        val cs = sum.inv() and 0xFFFF
        return byteArrayOf(0x55, 0xAA.toByte()) + core + byteArrayOf((cs and 0xFF).toByte(), (cs shr 8).toByte())
    }

    fun read(reg: Int, n: Int) = frame(0x01, reg, byteArrayOf(n.toByte()))
    fun write(reg: Int, v: Int) = frame(0x03, reg, byteArrayOf((v and 0xFF).toByte(), (v shr 8).toByte()))

    fun parse(buf: ByteArray): Pair<List<Frame>, ByteArray> {
        val out = ArrayList<Frame>()
        var i = 0
        while (i + 1 < buf.size) {
            if (buf[i] != 0x55.toByte() || buf[i + 1] != 0xAA.toByte()) { i++; continue }
            if (i + 2 >= buf.size) break
            val l = buf[i + 2].toInt() and 0xFF
            val total = l + 6
            if (i + total > buf.size) break
            var sum = 0
            for (k in i + 2 until i + total - 2) sum += buf[k].toInt() and 0xFF
            val cs = (buf[i + total - 2].toInt() and 0xFF) or ((buf[i + total - 1].toInt() and 0xFF) shl 8)
            if (l >= 2 && (sum.inv() and 0xFFFF) == cs) {
                out.add(Frame(buf[i + 3].toInt() and 0xFF, buf[i + 4].toInt() and 0xFF,
                    buf[i + 5].toInt() and 0xFF, buf.copyOfRange(i + 6, i + total - 2)))
                i += total
            } else i += 2
        }
        return out to buf.copyOfRange(i, buf.size)
    }

    fun live(d: ByteArray, old: Telemetry): Telemetry? {
        if (d.size < 22) return null
        fun u8(i: Int) = d[i].toInt() and 0xFF
        fun u16(i: Int) = u8(i) or (u8(i + 1) shl 8)
        fun s16(i: Int) = u16(i).toShort().toInt()
        return old.copy(
            error = u16(0),
            battery = u8(7).coerceIn(0, 100),
            speed = kotlin.math.abs(s16(8)) / 1000f,
            total = (u16(12).toLong() or (u16(14).toLong() shl 16)) / 1000f,
            trip = u16(16) / 100f,
            uptime = u16(18),
            temp = s16(20) / 10f
        )
    }
}
