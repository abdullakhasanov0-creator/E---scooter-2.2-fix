package com.limonchik.escooter

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun EScooterTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF4DD0E1), secondary = Color(0xFF8C7CFF),
        background = Color(0xFF0B0F17), surface = Color(0xFF121826), surfaceVariant = Color(0xFF1B2335),
        onBackground = Color(0xFFEAF0FA), onSurface = Color(0xFFEAF0FA), onSurfaceVariant = Color(0xFF9AA7BD)
    ) else lightColorScheme(
        primary = Color(0xFF00838F), secondary = Color(0xFF5B4BDB),
        background = Color(0xFFF2F5FA), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFE6EBF4),
        onBackground = Color(0xFF0B0F17), onSurface = Color(0xFF0B0F17), onSurfaceVariant = Color(0xFF55627A)
    )
    MaterialTheme(colorScheme = cs, content = content)
}
